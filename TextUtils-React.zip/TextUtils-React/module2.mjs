const a = "Harry";
const b = "Rohan";
const c = "Aakash";
const d = "Priyanka";

export default b;  
export {a};  
export {c};  
export {d};  